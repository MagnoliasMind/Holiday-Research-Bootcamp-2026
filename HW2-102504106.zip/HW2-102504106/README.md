# HW2-102504106

本项目为第二次挑战作业，主要完成以下两个任务：

1. 测量 SGLang Radix Cache 前缀缓存的效果，对比 Shared Prefix 与 Dispersed Prefix 两种 workload。
2. 阅读 SGLang v0.5.14 源码，追踪一条 `/generate` 请求从接收、调度、Prefix Cache 匹配、Prefill/Decode、KV Cache 更新到流式返回的主要处理流程。

---

## 1. Environment

实验环境：

- OS: Windows 11 + WSL2 Ubuntu
- GPU: NVIDIA GeForce RTX 5060 Laptop GPU
- GPU Memory: 8151 MiB
- NVIDIA Driver: 596.56
- Python: 3.12.3
- PyTorch: 2.11.0+cu130
- CUDA: 13.0
- SGLang: 0.5.14
- Ray: 2.56.0
- Model: Qwen/Qwen3-0.6B
- Local model path: `/home/liu/models/Qwen3-0.6B`

---

## 2. Installation

进入项目目录并创建 Python 虚拟环境：

```bash
cd ~/projects/sgattemp

python3 -m venv .venv
source .venv/bin/activate
```

安装本实验所需依赖，并确保 SGLang 与 Ray 使用指定版本：

```bash
pip install "sglang==0.5.14"
pip install "ray==2.56.0"
pip install transformers requests
```

实验运行前可通过以下命令检查环境：

```bash
python -c "import sys, torch, sglang, ray; \
print('Python:', sys.version.split()[0]); \
print('PyTorch:', torch.__version__); \
print('SGLang:', sglang.__version__); \
print('Ray:', ray.__version__); \
print('CUDA:', torch.version.cuda)"
```

---

## 3. Start SGLang Server

首先激活虚拟环境：

```bash
cd ~/projects/sgattemp
source .venv/bin/activate
```

使用本地 Qwen3-0.6B 模型启动 SGLang Server：

```bash
python -m sglang.launch_server \
    --model-path /home/liu/models/Qwen3-0.6B \
    --host 127.0.0.1 \
    --port 30000
```

实验保持 SGLang 默认 Radix Cache 开启。

Server 启动完成后保持该终端运行，并在另一个终端中执行 benchmark。

---

## 4. Run / Replay Benchmark

打开新的 WSL 终端：

```bash
cd ~/projects/sgattemp
source .venv/bin/activate
cd HW2-102504106
```

运行正式 benchmark：

```bash
python src/benchmark_prefix_cache.py
```

Benchmark 使用 SGLang 原生 `/generate` 接口发送 `input_ids`，并使用 streaming response。

主要实验配置：

- Measurement requests per workload: 32
- Maximum concurrency: 8
- Prompt length: 2112 tokens
- Output length: 16 tokens
- `temperature = 0`
- `max_new_tokens = 16`
- `ignore_eos = true`
- `sampling_seed = 2026`

Shared Prefix workload：

- Shared prefix: 2048 tokens
- Unique suffix: 64 tokens
- 每个请求总输入长度：2112 tokens
- 正式测量前额外发送 shared-prefix warmup request，该请求不计入结果。

Dispersed Prefix workload：

- 每个请求总输入长度：2112 tokens
- 32 个请求的首 token 均不同，使请求之间无法复用公共 prefix。
- 不进行 shared-prefix warmup。

脚本在实验开始前进行 service warmup，并在每组实验开始前调用 `/flush_cache`。

---

## 5. Source Code

正式 benchmark 脚本：

```text
src/benchmark_prefix_cache.py
```

该脚本主要负责：

- 构造 Shared Prefix workload；
- 构造 Dispersed Prefix workload；
- 检查两组 workload 输入长度及控制变量；
- 调用 `/flush_cache`；
- 执行 service warmup 与 shared-prefix warmup；
- 使用最大并发数 8 发送 32 条测量请求；
- 读取 streaming response；
- 从返回的 `meta_info` 中记录 `prompt_tokens`、`cached_tokens` 和 `completion_tokens`；
- 测量 TTFT、TPOT 与 E2E latency；
- 计算 success rate、throughput、cache hit rate 和 actual Prefill token count；
- 保存逐请求结果和汇总结果。

Cache hit rate 定义为：

```text
sum(cached_tokens) / sum(prompt_tokens)
```

Actual Prefill token count 定义为：

```text
sum(prompt_tokens - cached_tokens)
```

---

## 6. Results

正式实验结果保存在：

```text
results/
├── shared_prefix/
│   ├── raw_results.json
│   └── summary.json
└── dispersed_prefix/
    ├── raw_results.json
    └── summary.json
```

其中：

- `raw_results.json`：保存 32 条测量请求的逐请求结果；
- `summary.json`：保存对应 workload 的汇总指标。

报告 Task 1 对照表中的 Shared Prefix 数据对应：

```text
results/shared_prefix/summary.json
```

报告 Task 1 对照表中的 Dispersed Prefix 数据对应：

```text
results/dispersed_prefix/summary.json
```

逐请求数据分别对应：

```text
results/shared_prefix/raw_results.json
results/dispersed_prefix/raw_results.json
```

---

## 7. Final Benchmark Results

| Metric | Shared Prefix | Dispersed Prefix |
|---|---:|---:|
| Success Rate | 100.00% | 100.00% |
| Throughput (req/s) | 51.2564 | 7.9600 |
| Cache Hit Rate | 96.97% | 0.00% |
| Actual Prefill Tokens | 2048 | 67584 |
| TTFT p50 (s) | 0.049879 | 0.547650 |
| TTFT p95 (s) | 0.060923 | 0.805862 |
| TPOT p50 (s) | 0.006851 | 0.030235 |
| TPOT p95 (s) | 0.007827 | 0.052515 |
| E2E p50 (s) | 0.153300 | 1.003998 |
| E2E p95 (s) | 0.164763 | 1.010222 |

两组均成功完成 32 条测量请求，并保持相同的输入长度、输出长度、请求顺序和最大并发数。

---

## 8. Task 2 Source Trace

Task 2 基于本实验环境中安装的 SGLang v0.5.14 源码，沿 `/generate` 请求的主要执行路径进行阅读。

主要涉及文件包括：

```text
srt/entrypoints/http_server.py
srt/managers/tokenizer_manager.py
srt/managers/scheduler.py
srt/managers/schedule_policy.py
srt/managers/scheduler_components/request_receiver.py
srt/managers/scheduler_components/batch_result_processor.py
srt/managers/scheduler_components/output_streamer.py
srt/managers/tp_worker.py
srt/managers/detokenizer_manager.py
srt/mem_cache/radix_cache.py
srt/mem_cache/common.py
```

主要流程为：

```text
/generate
→ TokenizerManager
→ Scheduler
→ waiting_queue
→ Prefix Match
→ PrefillAdder / ScheduleBatch
→ Model Forward (Prefill / Decode)
→ KV Cache Update
→ Output Streamer
→ Detokenizer
→ TokenizerManager
→ HTTP SSE streaming response
```

详细流程图、关键函数以及 Prefix Cache 工作过程见 `report.pdf`。

---

## 9. Directory Structure

最终提交目录结构：

```text
HW2-102504106/
├── README.md
├── report.pdf
├── AI 使用说明情况（第二次挑战）.pdf
├── src/
│   └── benchmark_prefix_cache.py
├── target1/
├── results/
│   ├── shared_prefix/
│   │   ├── raw_results.json
│   │   └── summary.json
│   └── dispersed_prefix/
│       ├── raw_results.json
│       └── summary.json
├── shared_prefix/
└── dispersed_prefix/
```

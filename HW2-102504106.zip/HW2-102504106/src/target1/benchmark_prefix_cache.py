import json
import time
import statistics
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from transformers import AutoTokenizer

BASE_URL = "http://127.0.0.1:30000"
MODEL_PATH = "/home/liu/models/Qwen3-0.6B"

NUM_REQUESTS = 32
MAX_CONCURRENCY = 8

SHARED_PREFIX_LEN = 2048
UNIQUE_SUFFIX_LEN = 64
PROMPT_LEN = 2112

MAX_NEW_TOKENS = 16
SAMPLING_SEED = 2026

RESULTS_DIR = Path("results")

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)


# ============================================================
# Server utilities
# ============================================================

def flush_cache():
    response = requests.post(
        f"{BASE_URL}/flush_cache",
        timeout=30,
    )
    response.raise_for_status()

    print("Flush cache:")
    print(response.text)

def generate(input_ids):

    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SAMPLING_SEED,
        },
        "stream": True,
    }

    # Time immediately before sending the request.
    start_time = time.perf_counter()

    response = requests.post(
        f"{BASE_URL}/generate",
        json=payload,
        stream=True,
        timeout=300,
    )
    response.raise_for_status()

    first_token_time = None
    last_token_time = None
    last_data = None

    for line in response.iter_lines(decode_unicode=True):
        if not line:
            continue

        if not line.startswith("data: "):
            continue

        data_str = line[len("data: "):]

        if data_str == "[DONE]":
            break

        # Record the arrival time of this streaming token event.
        now = time.perf_counter()

        data = json.loads(data_str)

        # The first valid event corresponds to the first generated token.
        if first_token_time is None:
            first_token_time = now

        # Updated for every event, so after the loop this is
        # the arrival time of the final generated token.
        last_token_time = now

        last_data = data

    # Time when the complete streaming response has finished.
    finish_time = time.perf_counter()

    if last_data is None:
        raise RuntimeError(
            "No streaming data received from SGLang."
        )

    meta = last_data["meta_info"]

    prompt_tokens = meta.get("prompt_tokens", 0)
    cached_tokens = meta.get("cached_tokens", 0)
    completion_tokens = meta.get("completion_tokens", 0)

    # --------------------------------------------------------
    # TTFT: Time To First Token
    # --------------------------------------------------------

    if first_token_time is not None:
        ttft = first_token_time - start_time
    else:
        ttft = None

    # --------------------------------------------------------
    # TPOT: Time Per Output Token
    #
    # The first output token is accounted for by TTFT.
    # For N output tokens, there are N - 1 decode intervals
    # between the first and final token.
    # --------------------------------------------------------

    if (
        completion_tokens > 1
        and first_token_time is not None
        and last_token_time is not None
    ):
        tpot = (
            last_token_time - first_token_time
        ) / (completion_tokens - 1)
    else:
        tpot = None

    # --------------------------------------------------------
    # End-to-end latency
    # --------------------------------------------------------

    e2e_latency = finish_time - start_time

    return {
        "success": True,
        "prompt_tokens": prompt_tokens,
        "cached_tokens": cached_tokens,
        "actual_prefill_tokens": (
            prompt_tokens - cached_tokens
        ),
        "completion_tokens": completion_tokens,
        "ttft": ttft,
        "tpot": tpot,
        "e2e_latency": e2e_latency,
    }

def generate1(input_ids):

    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SAMPLING_SEED,
        },
        "stream": True,
    }

    start_time = time.perf_counter()

    response = requests.post(
        f"{BASE_URL}/generate",
        json=payload,
        stream=True,
        timeout=300,
    )
    response.raise_for_status()

    first_token_time = None
    last_token_time = None
    last_data = None

    for line in response.iter_lines(decode_unicode=True):
        if not line:
            continue

        if not line.startswith("data: "):
            continue

        data_str = line[len("data: "):]

        if data_str == "[DONE]":
            break

        now = time.perf_counter()

        data = json.loads(data_str)

        if first_token_time is None:
            first_token_time = now

        # Every valid streaming event corresponds to the latest generated token.
        last_token_time = now
        last_data = data

    finish_time = time.perf_counter()

    if last_data is None:
        raise RuntimeError("No streaming data received from SGLang.")

    meta = last_data["meta_info"]

    prompt_tokens = meta.get("prompt_tokens", 0)
    cached_tokens = meta.get("cached_tokens", 0)
    completion_tokens = meta.get("completion_tokens", 0)

    ttft = (
        first_token_time - start_time
        if first_token_time is not None
        else None
    )

    e2e_latency = finish_time - start_time

    # Average time per output token after the first token.
    if completion_tokens > 1 and ttft is not None:
        tpot = (
            e2e_latency - ttft
        ) / (completion_tokens - 1)
    else:
        tpot = None

    return {
        "success": True,
        "prompt_tokens": prompt_tokens,
        "cached_tokens": cached_tokens,
        "actual_prefill_tokens": prompt_tokens - cached_tokens,
        "completion_tokens": completion_tokens,
        "ttft": ttft,
        "tpot": tpot,
        "e2e_latency": e2e_latency,
    }

# ============================================================
# Workload construction
# ============================================================

def get_unique_first_tokens():

    words = [
        "apple",
        "banana",
        "computer",
        "science",
        "music",
        "water",
        "house",
        "school",
        "world",
        "book",
        "city",
        "game",
        "time",
        "people",
        "work",
        "system",
        "model",
        "data",
        "language",
        "number",
        "student",
        "teacher",
        "paper",
        "research",
        "network",
        "machine",
        "learning",
        "attention",
        "memory",
        "cache",
        "token",
        "request",
    ]

    token_ids = []

    for word in words:
        ids = tokenizer.encode(
            word,
            add_special_tokens=False,
        )

        if len(ids) != 1:
            raise ValueError(
                f"{word!r} is not encoded as exactly one token: {ids}"
            )

        token_ids.append(ids[0])

    if len(set(token_ids)) != NUM_REQUESTS:
        raise ValueError(
            "The selected first-token IDs are not all unique."
        )

    return token_ids

def build_shared_prefix():
    base_text = (
        "Why students always get a lot of assignments in their holidays? "
        "A recent research study shows that students who are given a lot "
        "of assignments during their holidays tend to have higher levels "
        "of stress and anxiety. "
        "It is recommended that students should be given a longer holiday "
        "to ease their pressure. "
    )

    base_ids = tokenizer.encode(
        base_text,
        add_special_tokens=False,
    )

    repeat_count = SHARED_PREFIX_LEN // len(base_ids) + 1

    shared_prefix = (
        base_ids * repeat_count
    )[:SHARED_PREFIX_LEN]

    assert len(shared_prefix) == SHARED_PREFIX_LEN

    return shared_prefix


def make_unique_suffix(request_id, unique_first_tokens):

    first_token = unique_first_tokens[request_id]

    body_text = (
        "This is the unique suffix used for the prefix cache experiment. "
        "Each request contains exactly sixty four suffix tokens. "
    )

    body_ids = tokenizer.encode(
        body_text,
        add_special_tokens=False,
    )

    repeat_count = (
        (UNIQUE_SUFFIX_LEN - 1) // len(body_ids) + 1
    )

    body = (
        body_ids * repeat_count
    )[:UNIQUE_SUFFIX_LEN - 1]

    suffix = [first_token] + body

    assert len(suffix) == UNIQUE_SUFFIX_LEN

    return suffix


def build_shared_workload(
    shared_prefix,
    unique_first_tokens,):
    workload = []

    for request_id in range(NUM_REQUESTS):
        suffix = make_unique_suffix(
            request_id,
            unique_first_tokens,
        )

        prompt = shared_prefix + suffix

        workload.append(prompt)

    return workload


def build_dispersed_workload(unique_first_tokens):
   
    body_text = (
        "This request belongs to the dispersed prefix workload. "
        "Its tokens are used to prevent long prefix reuse between requests. "
    )

    body_ids = tokenizer.encode(
        body_text,
        add_special_tokens=False,
    )

    repeat_count = (
        (PROMPT_LEN - 1) // len(body_ids) + 1
    )

    body = (
        body_ids * repeat_count
    )[:PROMPT_LEN - 1]

    workload = []

    for request_id in range(NUM_REQUESTS):
        first_token = unique_first_tokens[request_id]

        prompt = [first_token] + body

        workload.append(prompt)

    return workload


# ============================================================
# Workload validation
# ============================================================

def validate_workloads(
    shared_workload,
    dispersed_workload,
    shared_prefix,):
    assert len(shared_workload) == NUM_REQUESTS
    assert len(dispersed_workload) == NUM_REQUESTS

    assert all(
        len(prompt) == PROMPT_LEN
        for prompt in shared_workload
    )

    assert all(
        len(prompt) == PROMPT_LEN
        for prompt in dispersed_workload
    )

    assert all(
        prompt[:SHARED_PREFIX_LEN] == shared_prefix
        for prompt in shared_workload
    )

    shared_suffix_first_tokens = [
        prompt[SHARED_PREFIX_LEN]
        for prompt in shared_workload
    ]

    assert (
        len(set(shared_suffix_first_tokens))
        == NUM_REQUESTS
    )

    dispersed_first_tokens = [
        prompt[0]
        for prompt in dispersed_workload
    ]

    assert (
        len(set(dispersed_first_tokens))
        == NUM_REQUESTS
    )

    for request_id in range(NUM_REQUESTS):
        assert (
            len(shared_workload[request_id])
            == len(dispersed_workload[request_id])
        )

    print("Workload validation passed.")
    print(f"Requests per group : {NUM_REQUESTS}")
    print(f"Prompt length      : {PROMPT_LEN}")
    print(f"Shared prefix      : {SHARED_PREFIX_LEN}")
    print(f"Unique suffix      : {UNIQUE_SUFFIX_LEN}")

# ============================================================
# Warmup
# ============================================================

def service_warmup():
   
    print("\nRunning service warmup...")

    ids = tokenizer.encode(
        "SGLang service warmup.",
        add_special_tokens=False,
    )

    generate(ids)

    print("Service warmup completed.")


def shared_prefix_warmup(shared_prefix):

    print("Running shared-prefix warmup...")

    generate(shared_prefix)

    print("Shared-prefix warmup completed.")


# ============================================================
# Concurrent benchmark
# ============================================================

def run_workload(workload, group_name):
    results = [None] * len(workload)

    group_start = time.perf_counter()

    with ThreadPoolExecutor(
        max_workers=MAX_CONCURRENCY
    ) as executor:

        futures = {}

        for request_id, prompt in enumerate(workload):
            future = executor.submit(
                generate,
                prompt,
            )

            futures[future] = request_id

        for future in as_completed(futures):
            request_id = futures[future]

            try:
                result = future.result()
                result["request_id"] = request_id

            except Exception as exc:
                result = {
                    "request_id": request_id,
                    "success": False,
                    "error": str(exc),
                }

            results[request_id] = result

            print(
                f"[{group_name}] "
                f"request {request_id:02d} finished "
                f"success={result['success']}"
            )

    group_end = time.perf_counter()

    total_time = group_end - group_start

    return results, total_time


# ============================================================
# Statistics
# ============================================================

def percentile(values, percentile_value):
    if not values:
        return None

    sorted_values = sorted(values)

    position = (
        percentile_value / 100
        * (len(sorted_values) - 1)
    )

    lower = int(position)
    upper = min(
        lower + 1,
        len(sorted_values) - 1,
    )

    fraction = position - lower

    return (
        sorted_values[lower]
        + (
            sorted_values[upper]
            - sorted_values[lower]
        )
        * fraction
    )


def summarize_results(results, total_time):
    successful = [
        result
        for result in results
        if result["success"]
    ]

    success_rate = (
        len(successful) / len(results)
    )

    total_prompt_tokens = sum(
        result["prompt_tokens"]
        for result in successful
    )

    total_cached_tokens = sum(
        result["cached_tokens"]
        for result in successful
    )

    actual_prefill_tokens = sum(
        result["actual_prefill_tokens"]
        for result in successful
    )

    total_completion_tokens = sum(
        result["completion_tokens"]
        for result in successful
    )

    cache_hit_rate = (
        total_cached_tokens / total_prompt_tokens
        if total_prompt_tokens > 0
        else 0
    )

    ttfts = [
        result["ttft"]
        for result in successful
        if result["ttft"] is not None
    ]

    tpots = [
        result["tpot"]
        for result in successful
        if result["tpot"] is not None
    ]

    e2es = [
        result["e2e_latency"]
        for result in successful
    ]

    # Request throughput: successfully completed requests / wall-clock time.
    throughput = (
        len(successful) / total_time
        if total_time > 0
        else 0
    )

    summary = {
        "num_requests": len(results),
        "successful_requests": len(successful),
        "success_rate": success_rate,
        "total_time": total_time,
        "throughput_requests_per_second": throughput,

        "total_prompt_tokens": total_prompt_tokens,
        "total_cached_tokens": total_cached_tokens,
        "cache_hit_rate": cache_hit_rate,
        "actual_prefill_tokens": actual_prefill_tokens,
        "total_completion_tokens": total_completion_tokens,

        "ttft_p50": percentile(ttfts, 50),
        "ttft_p95": percentile(ttfts, 95),

        "tpot_p50": percentile(tpots, 50),
        "tpot_p95": percentile(tpots, 95),

        "e2e_p50": percentile(e2es, 50),
        "e2e_p95": percentile(e2es, 95),
    }

    return summary


# ============================================================
# Save results
# ============================================================

def save_results(group_name, results, summary):
    output_dir = RESULTS_DIR / group_name

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    raw_path = output_dir / "raw_results.json"
    summary_path = output_dir / "summary.json"

    with open(
        raw_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            results,
            file,
            indent=2,
            ensure_ascii=False,
        )

    with open(
        summary_path,
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            summary,
            file,
            indent=2,
            ensure_ascii=False,
        )

    print(f"Saved: {raw_path}")
    print(f"Saved: {summary_path}")


# ============================================================
# Display
# ============================================================

def print_summary(group_name, summary):
    print("\n" + "=" * 60)
    print(group_name)
    print("=" * 60)

    print(
        "Success rate       :",
        f"{summary['success_rate']:.2%}",
    )

    print(
        "Throughput         :",
        f"{summary['throughput_requests_per_second']:.4f} req/s",
    )

    print(
        "Cache hit rate     :",
        f"{summary['cache_hit_rate']:.2%}",
    )

    print(
        "Actual Prefill     :",
        summary["actual_prefill_tokens"],
    )

    print(
        "TTFT p50           :",
        f"{summary['ttft_p50']:.6f} s",
    )

    print(
        "TTFT p95           :",
        f"{summary['ttft_p95']:.6f} s",
    )

    print(
        "TPOT p50           :",
        f"{summary['tpot_p50']:.6f} s",
    )

    print(
        "TPOT p95           :",
        f"{summary['tpot_p95']:.6f} s",
    )

    print(
        "E2E p50            :",
        f"{summary['e2e_p50']:.6f} s",
    )

    print(
        "E2E p95            :",
        f"{summary['e2e_p95']:.6f} s",
    )


# ============================================================
# Main
# ============================================================

def main():
    print("Building workloads...")

    unique_first_tokens = get_unique_first_tokens()
    shared_prefix = build_shared_prefix()

    shared_workload = build_shared_workload(
        shared_prefix,
        unique_first_tokens,
    )

    dispersed_workload = build_dispersed_workload(
        unique_first_tokens,
    )

    validate_workloads(
        shared_workload,
        dispersed_workload,
        shared_prefix,
    )

    # --------------------------------------------------------
    # Service warmup
    # --------------------------------------------------------

    service_warmup()

    # --------------------------------------------------------
    # Shared-prefix experiment
    # --------------------------------------------------------

    print("\nPreparing shared-prefix experiment...")

    flush_cache()

    shared_prefix_warmup(shared_prefix)

    print("\nStarting shared-prefix benchmark...")

    shared_results, shared_total_time = run_workload(
        shared_workload,
        "shared_prefix",
    )

    shared_summary = summarize_results(
        shared_results,
        shared_total_time,
    )

    save_results(
        "shared_prefix",
        shared_results,
        shared_summary,
    )

    print_summary(
        "SHARED PREFIX",
        shared_summary,
    )

    # Ensure all shared requests are finished before flush.
    print("\nShared-prefix experiment completed.")

    # --------------------------------------------------------
    # Dispersed-prefix experiment
    # --------------------------------------------------------

    print("\nPreparing dispersed-prefix experiment...")

    flush_cache()

    print("\nStarting dispersed-prefix benchmark...")

    dispersed_results, dispersed_total_time = run_workload(
        dispersed_workload,
        "dispersed_prefix",
    )

    dispersed_summary = summarize_results(
        dispersed_results,
        dispersed_total_time,
    )

    save_results(
        "dispersed_prefix",
        dispersed_results,
        dispersed_summary,
    )

    print_summary(
        "DISPERSED PREFIX",
        dispersed_summary,
    )

    print("\nAll experiments completed.")


if __name__ == "__main__":
    main()
